require 'sinatra'

get('/') do
    erb(:index, locals:{ greeting: "Hello from index!" })
end