 # class App < Sinatra::Base

	require 'sinatra'
	require 'slim'
	require 'sqlite3'
	
	enable:sessions

	get('/') do
		slim(:index)
	end
	
	post('/register') do
		username = params["username"]
		password = params["password"]
		db = SQLite3::Database.new("login.sqlite")
		db.execute("INSERT INTO login (username,password) VALUES (?,?)", [username, password])
		slim(:tack)
	end
	
	
	
	get('/logga_in') do
		username = params["username"]
		password = params["password"]
		db = SQLite3::Database.new("login.sqlite")
		name = db.execute("SELECT username FROM login WHERE username="+username)
		if name != nil
			check = db.execute("SELECT password FROM login WHERE username="+username)
			if check == password
				session[yoursession] = db.execute("SELECT rowid FROM login WHERE username="+username)
				redirect("/home/" + username)
			end
		end
	end
#end